import mongoose from 'mongoose';

const StudentProfileSchema = new mongoose.Schema({
  user: {
    type: mongoose.Types.ObjectId,
    ref: 'User',
  },
  age: { type: Number },
  weight: { type: Number },
  bloodGroup: { type: String },
  certificatePhoto: { type: String },
  disabilityType: {
    type: String,
    enum: ['visual', 'hearing', 'mobility', 'cognitive', 'other'],
  },
  // Add more parameters as needed to categorize the disability
});

export default mongoose.model('StudentProfile', StudentProfileSchema);
 