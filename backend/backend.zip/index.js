import express from "express";
import cookieParser from "cookie-parser";
import mongoose from "mongoose";
import cors from "cors";  // Import the cors middleware
import dotenv from "dotenv";
import authRouter from "./routes/auth.js";
import studentRouter from "./routes/student.js";
import nodemailer from "nodemailer";

dotenv.config();

const app = express();
const port = process.env.PORT || 8000;

const corsOptions = {
    origin: "http://localhost:5173",
    credentials: true,
}

app.get('/', (req, res) => {
    res.send("Hello Worl!")
});

mongoose.set('strictQuery', false);
const connectDB = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        console.log('MongoDB database connected');
    } catch (err) {
        console.log('MongoDB connection failed');
    }
}

app.use(express.json());
app.use(cookieParser());
app.use(cors(corsOptions));
app.use('/api/auth', authRouter);
app.use('/api/students', studentRouter);

const transporter = nodemailer.createTransport({
    service: 'Gmail',
    auth: {
        user: 'kaustubh.h.mhatre@gmail.com',
        pass: 'vudc szce jtcg avqj',
    },
});

app.post('/api/send-email', (req, res) => {
    const { email, subject, message } = req.body;

    const mailOptions = {
        from: 'kaustubh.h.mhatre@gmail.com', // Sender's email address
        to: 'leena.h.mhatre@gmail.com', // Admin's email address
        subject: subject,
        text: `Email: ${email}\n\nMessage: ${message}`,
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error('Error sending email:', error);
            res.status(500).json({ success: false, message: 'Failed to send email' });
        } else {
            console.log('Email sent:', info.response);
            res.status(200).json({ success: true, message: 'Email sent successfully' });
        }
    });
});


app.listen(port, () => {
    connectDB(),
        console.log(`Server is listening to port : ${port}`)
})